'use strict';

// 扩展一些框架便利的方法
module.exports = {};
