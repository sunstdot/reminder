'use strict';

exports.alinode = {
  enable: true,
  package: 'egg-alinode',
};
